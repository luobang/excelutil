# ExcelUtil
用于导入导出Excel的Util包，基于Java的POI。可将List&lt;Bean>导出成Excel，或读取Excel成List&lt;Bean>,读取时有验证和Log。

Apache Maven
``` xml
<dependency>
    <groupId>com.sargeraswang.util</groupId>
    <artifactId>excel-util</artifactId>
    <version>1.2.4</version>
</dependency>
```
使用方式:[https://sargeraswang.com/blog/2018/11/27/excelutil-1-dot-2-1-doc/](https://sargeraswang.com/blog/2018/11/27/excelutil-1-dot-2-1-doc/)
